# Packaging-only adjustment: exact fresh static archive; no /usr/local search.
import os,runpy
import distutils.core
original=distutils.core.setup
def code_setup(**kw):
    for ext in kw['ext_modules']:
        ext.libraries=[n for n in ext.libraries if n!='pinproc']
        ext.library_dirs=[]
        ext.extra_objects=[os.environ['OVERLAY_STATIC_ARCHIVE']]
        ext.extra_link_args=['-Wl,-t','-Wl,-Map,'+os.environ['OVERLAY_LINK_MAP']]
    return original(**kw)
distutils.core.setup=code_setup
runpy.run_path('setup.py',run_name='__main__')
