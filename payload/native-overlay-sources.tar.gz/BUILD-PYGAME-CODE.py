# Python2-compatible packaging driver; upstream setup.py remains unchanged.
import os,sys,runpy
sys.path.insert(0,os.getcwd())
import setuptools
original=setuptools.setup
def code_setup(**kw):
    kw['packages']=['pygame','pygame.threads']
    kw['package_dir']={'pygame':'src_py','pygame.threads':'src_py/threads'}
    kw['data_files']=[]
    return original(**kw)
setuptools.setup=code_setup
runpy.run_path('setup.py',run_name='__main__')
