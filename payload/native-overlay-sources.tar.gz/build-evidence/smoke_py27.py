# Run ONLY with recipient-assembled Python 2.7, PYTHONDONTWRITEBYTECODE=1.
from __future__ import print_function
import importlib
import json
import os
import sys
import pygame
import pygame.freetype
import pygame.gfxdraw
import pygame.midi
import pinproc
# Every audited native overlay extension must load (without hardware creation).
module_dir=os.path.dirname(pygame.__file__)
loaded_extensions=[]
for filename in sorted(os.listdir(module_dir)):
    if filename.endswith('.so'):
        module='pygame.'+filename[:-3]
        importlib.import_module(module)
        loaded_extensions.append(module)
assert len(loaded_extensions)==34
import yaml
from PIL import Image
from cStringIO import StringIO

assert pygame.version.ver == '1.9.6'
assert not yaml.__with_libyaml__, 'Unreviewed _yaml extension must not be used'
assert yaml.safe_load('a: [1, 2]\n') == {'a': [1, 2]}
try:
    import _yaml
except ImportError:
    pass
else:
    raise AssertionError('_yaml unexpectedly available')
pygame.display.init()
pygame.display.set_mode((64, 64))  # Loads pygame default icon in SDL1.
pygame.font.init()
pygame.freetype.init()
font = pygame.font.Font(None, 18)
text = font.render('runtime smoke', True, (255, 255, 255))
assert text.get_width() > 0
ft = pygame.freetype.Font(None, 18)
assert ft.render('font smoke')[0].get_width() > 0
icons = []
for name in ('pygame_icon.bmp', 'pygame.ico', 'pygame_icon.tiff'):
    image = pygame.image.load(os.path.join(os.path.dirname(pygame.__file__), name))
    assert image.get_width() > 0
    icons.append(name)
# Decoder/encoder exercise, not just importing Pillow's Python wrapper.
for fmt in ('PNG', 'JPEG'):
    stream = StringIO()
    Image.new('RGB', (3, 2), (20, 30, 40)).save(stream, format=fmt)
    stream.seek(0)
    image = Image.open(stream)
    image.load()
    assert image.size == (3, 2)
pygame.mixer.init(frequency=22050, size=-16, channels=1)
pygame.mixer.Sound(buffer='\0' * 512).play()
pygame.mixer.quit()
pygame.quit()
print(json.dumps({'status': 'PASS', 'python': sys.version, 'pygame': pygame.version.ver,
                  'yaml': yaml.__version__, 'libyaml': yaml.__with_libyaml__,
                  'pillow': Image.__version__, 'pinproc': pinproc.__file__,
                  'default_font_rendered': True, 'freetype_font_rendered': True,
                  'pygame_native_extensions_imported': loaded_extensions,
                  'default_display_icon': True, 'icons_loaded': icons,
                  'pillow_png_jpeg': True, 'dummy_audio': True}, sort_keys=True))
